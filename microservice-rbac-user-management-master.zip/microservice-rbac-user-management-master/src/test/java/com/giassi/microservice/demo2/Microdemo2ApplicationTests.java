package com.giassi.microservice.demo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Microdemo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
