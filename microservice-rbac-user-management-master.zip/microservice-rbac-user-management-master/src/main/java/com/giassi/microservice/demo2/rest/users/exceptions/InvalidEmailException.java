package com.giassi.microservice.demo2.rest.users.exceptions;

public class InvalidEmailException extends java.lang.RuntimeException {

    public InvalidEmailException(String message) {
        super(message);
    }

}
