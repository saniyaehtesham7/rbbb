package com.giassi.microservice.demo2.rest.users.exceptions;

public class InvalidUserDataException extends java.lang.RuntimeException {

    public InvalidUserDataException(String message) {
        super(message);
    }

}
