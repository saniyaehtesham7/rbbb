package com.giassi.microservice.demo2.rest.users.exceptions;

public class InvalidUserIdentifierException extends java.lang.RuntimeException {

    public InvalidUserIdentifierException(String message) {
        super(message);
    }

}
