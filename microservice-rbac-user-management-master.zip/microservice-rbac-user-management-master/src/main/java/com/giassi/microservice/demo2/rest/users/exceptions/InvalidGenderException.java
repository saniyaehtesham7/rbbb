package com.giassi.microservice.demo2.rest.users.exceptions;

public class InvalidGenderException extends java.lang.RuntimeException {

    public InvalidGenderException(String message) {
        super(message);
    }

}
