package com.giassi.microservice.demo2.rest.users.exceptions;

public class UserNotFoundException extends java.lang.RuntimeException {

    public UserNotFoundException(String message) {
        super(message);
    }

}
