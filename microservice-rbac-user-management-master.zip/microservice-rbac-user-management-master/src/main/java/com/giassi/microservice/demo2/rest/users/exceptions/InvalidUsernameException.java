package com.giassi.microservice.demo2.rest.users.exceptions;

public class InvalidUsernameException extends java.lang.RuntimeException {

    public InvalidUsernameException(String message) {
        super(message);
    }

}
