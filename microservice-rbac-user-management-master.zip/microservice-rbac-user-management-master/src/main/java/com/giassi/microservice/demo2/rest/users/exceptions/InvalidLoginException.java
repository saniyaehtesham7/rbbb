package com.giassi.microservice.demo2.rest.users.exceptions;

public class InvalidLoginException extends java.lang.RuntimeException {

    public InvalidLoginException(String message) {
        super(message);
    }

}
